package com.coderscampus.arraylist;

public class CustomArrayList<T> implements CustomList<T>{
	
	private T[] items = (T[]) new Object[10];
	private int size = 0;
	
	private void resize() {
		T[] items2 =(T[]) new Object[size * 2];
		for (int i = 0; i < size; i++) {
			items2[i] = items[i];
		}
		items = items2;
		System.out.println("The object array has grown to the size of " + items.length);
	 }
	 
	@Override
	public boolean add(T item) {
		if(item != null) {
			if(size > 0 && (size + 1) % 10 == 1) {
				resize();
			}
				items[size] = item;
				size++;
				return true;
		}
		else {
			return false;
		}
	}
	        
	@Override
	public int getSize() {
		return size;
	}
	
	@Override
	public T get(int index) {
		if(index >= 0 && index < size) {
			return items[index];
		}
		else {
			return null;
		}
	}
}
