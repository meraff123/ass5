package com.coderscampus.arraylist;

public class ExampleApplication {

	public static void main(String[] args) {
		CustomList<String> myCustomList = new CustomArrayList<>();
		
		// adding first 10 elements
		for(int i = 1; i <= 10; i++)
			myCustomList.add("element " + i);
		
		// printing first 10 elements
		for(int i = 0; i < myCustomList.getSize(); i++) {
			System.out.println(myCustomList.get(i));
		}
		
		// adding 11th element
		myCustomList.add("element 11");
		
		// adding some more elements
		for(int i = 12; i <= 20; i++) {
			myCustomList.add("element " + i);
		}
		
		// printing new 10 elements
		for(int i = 10; i < myCustomList.getSize(); i++) {
			System.out.println(myCustomList.get(i));
		}
		
		// adding 21st element
		myCustomList.add("element 21");
	}
}
